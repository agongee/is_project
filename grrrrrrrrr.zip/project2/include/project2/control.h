struct control{
	double alpha;
	double d;
};
