
struct point{
	double x;
	double y;
	double th; // heading angle of RC car on the point
};
